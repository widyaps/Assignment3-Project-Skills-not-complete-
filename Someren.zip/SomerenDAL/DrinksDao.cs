﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Collections.ObjectModel;
using SomerenModel;

namespace SomerenDAL
{
    public class DrinksDao : BaseDao
    {
        public List<Drink> GetAllDrinks()
        {
            string query = "SELECT Id, Name, Price, Stock, Sold FROM [Drinks]";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }

        private List<Drink> ReadTables(DataTable dataTable)
        {
            List<Drink> drinks = new List<Drink>();

            foreach (DataRow dr in dataTable.Rows)
            {
                Drink drink = new Drink()
                {
                    Number = (int)dr["Id"],
                    Name = (string)(dr["Name"].ToString()),
                    Price = (float)(dr["Price"]),
                    Stock = (int)dr["Stock"],
                    Sold = (int)dr["Sold"],
                };
                drinks.Add(drink);
            }
            return drinks;
        }
    }
}
